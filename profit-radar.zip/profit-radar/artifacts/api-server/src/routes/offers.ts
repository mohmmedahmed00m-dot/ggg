import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, offersTable } from "@workspace/db";
import {
  ListOffersQueryParams,
  CreateOfferBody,
  GetOfferParams,
  UpdateOfferParams,
  UpdateOfferBody,
  DeleteOfferParams,
  AnalyzeOfferParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function computeProfitScore(data: {
  epc?: number | string | null;
  commissionPercent?: number | string | null;
  refundRate?: number | string | null;
  gravity?: number | string | null;
}): {
  profitScore: number;
  recommendation: string;
  saturationLevel: string;
  refundRisk: string;
  marketingAngle: string;
  estimatedWeeklyRevenue: number;
} {
  const epc = parseFloat(String(data.epc ?? 0)) || 0;
  const commission = parseFloat(String(data.commissionPercent ?? 50)) || 50;
  const refundRate = parseFloat(String(data.refundRate ?? 10)) || 10;
  const gravity = parseFloat(String(data.gravity ?? 0)) || 0;

  let score = 0;

  // EPC scoring (0-35 pts)
  if (epc >= 2.0) score += 35;
  else if (epc >= 1.5) score += 28;
  else if (epc >= 1.0) score += 21;
  else if (epc >= 0.5) score += 14;
  else score += Math.min(epc * 7, 7);

  // Commission scoring (0-20 pts)
  if (commission >= 75) score += 20;
  else if (commission >= 50) score += 15;
  else if (commission >= 40) score += 10;
  else score += 5;

  // Refund risk scoring (inverted, 0-25 pts)
  if (refundRate <= 5) score += 25;
  else if (refundRate <= 10) score += 20;
  else if (refundRate <= 15) score += 12;
  else if (refundRate <= 20) score += 6;
  else score += 0;

  // Gravity scoring (0-20 pts)
  if (gravity >= 200) score += 10; // very high = saturated, cap
  else if (gravity >= 100) score += 20;
  else if (gravity >= 50) score += 18;
  else if (gravity >= 20) score += 14;
  else if (gravity >= 5) score += 8;
  else score += 4;

  score = Math.min(100, Math.max(0, Math.round(score)));

  const recommendation = score >= 70 ? "promote" : score >= 45 ? "watch" : "avoid";

  const saturationLevel = gravity >= 200 ? "high" : gravity >= 80 ? "medium" : "low";

  const refundRisk = refundRate >= 20 ? "high" : refundRate >= 10 ? "medium" : "low";

  const angles = [
    "Focus on the time-saving angle — busy buyers convert better",
    "Lead with proof: showcase real results from existing buyers",
    "Use scarcity — highlight launch pricing before it expires",
    "Target the 'frustrated with current tools' segment",
    "Emphasize the ROI and payback within 30 days",
    "Position as the missing piece in their current workflow",
  ];
  const marketingAngle = angles[Math.floor(Math.random() * angles.length)];

  const estimatedWeeklyRevenue = Math.round(epc * 1000 * (commission / 100) * 0.3 * 100) / 100;

  return { profitScore: score, recommendation, saturationLevel, refundRisk, marketingAngle, estimatedWeeklyRevenue };
}

function formatOffer(offer: typeof offersTable.$inferSelect) {
  return {
    ...offer,
    epc: offer.epc != null ? parseFloat(String(offer.epc)) : null,
    commissionPercent: offer.commissionPercent != null ? parseFloat(String(offer.commissionPercent)) : null,
    refundRate: offer.refundRate != null ? parseFloat(String(offer.refundRate)) : null,
    gravity: offer.gravity != null ? parseFloat(String(offer.gravity)) : null,
    price: offer.price != null ? parseFloat(String(offer.price)) : null,
    estimatedWeeklyRevenue: offer.estimatedWeeklyRevenue != null ? parseFloat(String(offer.estimatedWeeklyRevenue)) : null,
    createdAt: offer.createdAt.toISOString(),
    updatedAt: offer.updatedAt.toISOString(),
  };
}

router.get("/offers", async (req, res): Promise<void> => {
  const parsed = ListOffersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { niche, platform, recommendation } = parsed.data;

  let query = db.select().from(offersTable).orderBy(desc(offersTable.profitScore)).$dynamic();

  const results = await query;
  let filtered = results;
  if (niche) filtered = filtered.filter(o => o.niche?.toLowerCase().includes(niche.toLowerCase()));
  if (platform) filtered = filtered.filter(o => o.platform === platform);
  if (recommendation) filtered = filtered.filter(o => o.recommendation === recommendation);

  res.json(filtered.map(formatOffer));
});

router.get("/offers/weekly-top", async (_req, res): Promise<void> => {
  const results = await db
    .select()
    .from(offersTable)
    .where(eq(offersTable.recommendation, "promote"))
    .orderBy(desc(offersTable.profitScore))
    .limit(5);

  res.json(results.map(formatOffer));
});

router.post("/offers", async (req, res): Promise<void> => {
  const parsed = CreateOfferBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const analysis = computeProfitScore(parsed.data);

  const [offer] = await db
    .insert(offersTable)
    .values({
      title: parsed.data.title,
      platform: parsed.data.platform,
      url: parsed.data.url,
      vendorName: parsed.data.vendorName,
      niche: parsed.data.niche,
      epc: parsed.data.epc?.toString(),
      commissionPercent: parsed.data.commissionPercent?.toString(),
      refundRate: parsed.data.refundRate?.toString(),
      gravity: parsed.data.gravity?.toString(),
      price: parsed.data.price?.toString(),
      notes: parsed.data.notes,
      ...analysis,
      estimatedWeeklyRevenue: analysis.estimatedWeeklyRevenue.toString(),
    })
    .returning();

  res.status(201).json(formatOffer(offer));
});

router.get("/offers/:id", async (req, res): Promise<void> => {
  const params = GetOfferParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [offer] = await db.select().from(offersTable).where(eq(offersTable.id, params.data.id));
  if (!offer) {
    res.status(404).json({ error: "Offer not found" });
    return;
  }

  res.json(formatOffer(offer));
});

router.patch("/offers/:id", async (req, res): Promise<void> => {
  const params = UpdateOfferParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateOfferBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Partial<typeof offersTable.$inferInsert> = {};
  if (parsed.data.title != null) updateData.title = parsed.data.title;
  if (parsed.data.platform != null) updateData.platform = parsed.data.platform;
  if (parsed.data.url != null) updateData.url = parsed.data.url;
  if (parsed.data.vendorName != null) updateData.vendorName = parsed.data.vendorName;
  if (parsed.data.niche != null) updateData.niche = parsed.data.niche;
  if (parsed.data.epc != null) updateData.epc = parsed.data.epc.toString();
  if (parsed.data.commissionPercent != null) updateData.commissionPercent = parsed.data.commissionPercent.toString();
  if (parsed.data.refundRate != null) updateData.refundRate = parsed.data.refundRate.toString();
  if (parsed.data.gravity != null) updateData.gravity = parsed.data.gravity.toString();
  if (parsed.data.price != null) updateData.price = parsed.data.price.toString();
  if (parsed.data.notes != null) updateData.notes = parsed.data.notes;

  const [offer] = await db
    .update(offersTable)
    .set(updateData)
    .where(eq(offersTable.id, params.data.id))
    .returning();

  if (!offer) {
    res.status(404).json({ error: "Offer not found" });
    return;
  }

  res.json(formatOffer(offer));
});

router.delete("/offers/:id", async (req, res): Promise<void> => {
  const params = DeleteOfferParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [offer] = await db.delete(offersTable).where(eq(offersTable.id, params.data.id)).returning();
  if (!offer) {
    res.status(404).json({ error: "Offer not found" });
    return;
  }

  res.sendStatus(204);
});

router.post("/offers/:id/analyze", async (req, res): Promise<void> => {
  const params = AnalyzeOfferParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existing] = await db.select().from(offersTable).where(eq(offersTable.id, params.data.id));
  if (!existing) {
    res.status(404).json({ error: "Offer not found" });
    return;
  }

  const analysis = computeProfitScore(existing);

  const [offer] = await db
    .update(offersTable)
    .set({ ...analysis, estimatedWeeklyRevenue: analysis.estimatedWeeklyRevenue.toString() })
    .where(eq(offersTable.id, params.data.id))
    .returning();

  res.json(formatOffer(offer!));
});

export default router;
