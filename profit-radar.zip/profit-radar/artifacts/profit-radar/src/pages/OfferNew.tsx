import { useLocation } from "wouter";
import { useCreateOffer, getListOffersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Zap } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  title: z.string().min(1, "Title is required"),
  platform: z.string().min(1, "Platform is required"),
  url: z.string().optional(),
  vendorName: z.string().optional(),
  niche: z.string().optional(),
  epc: z.coerce.number().optional(),
  commissionPercent: z.coerce.number().min(0).max(100).optional(),
  refundRate: z.coerce.number().min(0).max(100).optional(),
  gravity: z.coerce.number().optional(),
  price: z.coerce.number().optional(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

export default function OfferNew() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createOffer = useCreateOffer();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      title: "",
      platform: "jvzoo",
      url: "",
      vendorName: "",
      niche: "",
      notes: "",
    },
  });

  function onSubmit(values: FormValues) {
    createOffer.mutate(
      { data: { ...values, platform: values.platform } },
      {
        onSuccess: offer => {
          queryClient.invalidateQueries({ queryKey: getListOffersQueryKey() });
          toast({ title: "Offer analyzed", description: `Profit Score: ${offer.profitScore}/100` });
          setLocation(`/offers/${offer.id}`);
        },
        onError: () => {
          toast({ title: "Failed to add offer", variant: "destructive" });
        },
      }
    );
  }

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/offers">
          <Button variant="ghost" size="icon" className="h-8 w-8" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-xl font-bold text-foreground">Scan New Offer</h1>
          <p className="text-sm text-muted-foreground">Enter offer details to get your profit score</p>
        </div>
      </div>

      <div className="bg-card border border-card-border rounded-xl p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Offer Title *</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. AI Traffic Dominator Pro" {...field} data-testid="input-offer-title" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="platform"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Platform *</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger data-testid="select-platform">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="jvzoo">JVZoo</SelectItem>
                        <SelectItem value="warriorplus">WarriorPlus</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="niche"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Niche</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Email Marketing" {...field} data-testid="input-niche" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="url"
                render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Offer URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://jvzoo.com/..." {...field} data-testid="input-offer-url" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="border-t border-border pt-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Performance Metrics</p>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="epc"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>EPC ($)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="1.25" {...field} data-testid="input-epc" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="commissionPercent"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Commission (%)</FormLabel>
                      <FormControl>
                        <Input type="number" step="1" placeholder="50" {...field} data-testid="input-commission" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="refundRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Refund Rate (%)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.1" placeholder="8" {...field} data-testid="input-refund-rate" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="gravity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gravity Score</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.1" placeholder="45" {...field} data-testid="input-gravity" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price ($)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="27" {...field} data-testid="input-price" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="vendorName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. John Smith" {...field} data-testid="input-vendor-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Any additional context about this offer..." rows={2} {...field} data-testid="input-notes" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full gap-2"
              disabled={createOffer.isPending}
              data-testid="button-submit-offer"
            >
              <Zap className="w-4 h-4" />
              {createOffer.isPending ? "Analyzing..." : "Analyze Offer"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
