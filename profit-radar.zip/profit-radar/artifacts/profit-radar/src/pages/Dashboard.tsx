import { Link } from "wouter";
import { useGetDashboardStats, useGetProfitForecast, useGetWeeklyTopOffers } from "@workspace/api-client-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp, Target, AlertTriangle, Activity, Plus, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import RecommendationBadge from "@/components/RecommendationBadge";
import ProfitScoreGauge from "@/components/ProfitScoreGauge";

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ElementType;
  accent: string;
}) {
  return (
    <div className="bg-card border border-card-border rounded-xl p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${accent}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div className="text-2xl font-bold text-foreground" data-testid={`stat-value-${label.toLowerCase().replace(/\s+/g, "-")}`}>{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5 font-medium">{label}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}

const COLORS: Record<string, string> = {
  promote: "#22c55e",
  watch: "#f59e0b",
  avoid: "#ef4444",
};

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats();
  const { data: forecast, isLoading: forecastLoading } = useGetProfitForecast();
  const { data: topOffers, isLoading: topLoading } = useGetWeeklyTopOffers();

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Intelligence Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Your affiliate profit command center</p>
        </div>
        <Link href="/offers/new">
          <Button size="sm" className="gap-1.5" data-testid="button-add-offer">
            <Plus className="w-3.5 h-3.5" />
            Scan Offer
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statsLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-card border border-card-border rounded-xl p-5">
              <Skeleton className="h-8 w-8 rounded-lg mb-3" />
              <Skeleton className="h-7 w-16 mb-1" />
              <Skeleton className="h-3 w-24" />
            </div>
          ))
        ) : stats ? (
          <>
            <StatCard
              label="Total Offers"
              value={stats.totalOffers}
              icon={Activity}
              accent="bg-primary/10 text-primary"
            />
            <StatCard
              label="Promote"
              value={stats.promoteCount}
              sub={`${stats.watchCount} Watch · ${stats.avoidCount} Avoid`}
              icon={TrendingUp}
              accent="bg-emerald-500/10 text-emerald-400"
            />
            <StatCard
              label="Active Campaigns"
              value={stats.activeCampaigns}
              icon={Target}
              accent="bg-blue-500/10 text-blue-400"
            />
            <StatCard
              label="Est. Weekly Revenue"
              value={`$${stats.totalEstimatedRevenue.toFixed(0)}`}
              sub={`Avg score: ${stats.avgProfitScore}/100`}
              icon={TrendingUp}
              accent="bg-violet-500/10 text-violet-400"
            />
          </>
        ) : null}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Profit Forecast Chart */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Profit Forecast</h2>
              <p className="text-xs text-muted-foreground">Top offers estimated weekly revenue</p>
            </div>
          </div>
          {forecastLoading ? (
            <Skeleton className="h-48 w-full rounded-lg" />
          ) : forecast && forecast.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={forecast} barSize={32}>
                <XAxis
                  dataKey="offerTitle"
                  tick={{ fontSize: 10, fill: "#64748b" }}
                  tickFormatter={(v: string) => v.length > 12 ? v.slice(0, 12) + "…" : v}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "#64748b" }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v: number) => `$${v}`}
                />
                <Tooltip
                  contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: "8px", fontSize: 12 }}
                  formatter={(value: number) => [`$${value.toFixed(2)}`, "Est. Revenue"]}
                />
                <Bar dataKey="estimatedRevenue" radius={[4, 4, 0, 0]}>
                  {forecast.map((entry, idx) => (
                    <Cell key={idx} fill={COLORS[entry.recommendation] ?? "#3b82f6"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
              No promote offers yet — scan your first offer to see forecasts
            </div>
          )}
        </div>

        {/* Weekly Top Picks */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Top Picks This Week</h2>
              <p className="text-xs text-muted-foreground">Highest scored promote offers</p>
            </div>
            <Link href="/offers?recommendation=promote">
              <Button variant="ghost" size="sm" className="text-xs gap-1 h-7">
                View all <ArrowRight className="w-3 h-3" />
              </Button>
            </Link>
          </div>

          {topLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-14 rounded-lg" />
              ))}
            </div>
          ) : topOffers && topOffers.length > 0 ? (
            <div className="space-y-2">
              {topOffers.slice(0, 5).map((offer, idx) => (
                <Link key={offer.id} href={`/offers/${offer.id}`}>
                  <div
                    data-testid={`card-top-offer-${offer.id}`}
                    className="flex items-center gap-3 p-3 rounded-lg bg-accent/40 hover:bg-accent transition-colors cursor-pointer"
                  >
                    <span className="text-xs font-mono text-muted-foreground w-4 flex-shrink-0">#{idx + 1}</span>
                    <ProfitScoreGauge score={offer.profitScore} size="sm" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-foreground truncate">{offer.title}</div>
                      <div className="text-xs text-muted-foreground">{offer.platform} · {offer.niche ?? "General"}</div>
                    </div>
                    <RecommendationBadge recommendation={offer.recommendation} size="sm" />
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="h-32 flex flex-col items-center justify-center text-center gap-2">
              <AlertTriangle className="w-8 h-8 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">No promote offers yet</p>
              <Link href="/offers/new">
                <Button size="sm" variant="outline" className="text-xs h-7 mt-1">Scan your first offer</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
