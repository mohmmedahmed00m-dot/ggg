import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, campaignsTable, offersTable } from "@workspace/db";
import {
  ListCampaignsResponse,
  CreateCampaignBody,
  GetCampaignParams,
  UpdateCampaignParams,
  UpdateCampaignBody,
  DeleteCampaignParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function formatCampaign(
  campaign: typeof campaignsTable.$inferSelect,
  offerTitle?: string | null
) {
  return {
    ...campaign,
    offerTitle: offerTitle ?? null,
    estimatedRevenue: campaign.estimatedRevenue != null ? parseFloat(String(campaign.estimatedRevenue)) : null,
    actualRevenue: campaign.actualRevenue != null ? parseFloat(String(campaign.actualRevenue)) : null,
    createdAt: campaign.createdAt.toISOString(),
    updatedAt: campaign.updatedAt.toISOString(),
  };
}

router.get("/campaigns", async (_req, res): Promise<void> => {
  const results = await db
    .select({
      campaign: campaignsTable,
      offerTitle: offersTable.title,
    })
    .from(campaignsTable)
    .leftJoin(offersTable, eq(campaignsTable.offerId, offersTable.id))
    .orderBy(desc(campaignsTable.createdAt));

  const formatted = results.map(r => formatCampaign(r.campaign, r.offerTitle));
  res.json(ListCampaignsResponse.parse(formatted));
});

router.post("/campaigns", async (req, res): Promise<void> => {
  const parsed = CreateCampaignBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [campaign] = await db
    .insert(campaignsTable)
    .values({
      offerId: parsed.data.offerId,
      trafficSource: parsed.data.trafficSource,
      listSize: parsed.data.listSize,
      estimatedRevenue: parsed.data.estimatedRevenue?.toString(),
      startDate: parsed.data.startDate,
      endDate: parsed.data.endDate,
      notes: parsed.data.notes,
      status: "planned",
    })
    .returning();

  const [offer] = await db.select().from(offersTable).where(eq(offersTable.id, campaign.offerId));
  res.status(201).json(formatCampaign(campaign, offer?.title));
});

router.get("/campaigns/:id", async (req, res): Promise<void> => {
  const params = GetCampaignParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [result] = await db
    .select({ campaign: campaignsTable, offerTitle: offersTable.title })
    .from(campaignsTable)
    .leftJoin(offersTable, eq(campaignsTable.offerId, offersTable.id))
    .where(eq(campaignsTable.id, params.data.id));

  if (!result) {
    res.status(404).json({ error: "Campaign not found" });
    return;
  }

  res.json(formatCampaign(result.campaign, result.offerTitle));
});

router.patch("/campaigns/:id", async (req, res): Promise<void> => {
  const params = UpdateCampaignParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateCampaignBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Partial<typeof campaignsTable.$inferInsert> = {};
  if (parsed.data.trafficSource != null) updateData.trafficSource = parsed.data.trafficSource;
  if (parsed.data.listSize != null) updateData.listSize = parsed.data.listSize;
  if (parsed.data.estimatedRevenue != null) updateData.estimatedRevenue = parsed.data.estimatedRevenue.toString();
  if (parsed.data.actualRevenue != null) updateData.actualRevenue = parsed.data.actualRevenue.toString();
  if (parsed.data.startDate != null) updateData.startDate = parsed.data.startDate;
  if (parsed.data.endDate != null) updateData.endDate = parsed.data.endDate;
  if (parsed.data.status != null) updateData.status = parsed.data.status;
  if (parsed.data.notes != null) updateData.notes = parsed.data.notes;

  const [campaign] = await db
    .update(campaignsTable)
    .set(updateData)
    .where(eq(campaignsTable.id, params.data.id))
    .returning();

  if (!campaign) {
    res.status(404).json({ error: "Campaign not found" });
    return;
  }

  const [offer] = await db.select().from(offersTable).where(eq(offersTable.id, campaign.offerId));
  res.json(formatCampaign(campaign, offer?.title));
});

router.delete("/campaigns/:id", async (req, res): Promise<void> => {
  const params = DeleteCampaignParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [campaign] = await db
    .delete(campaignsTable)
    .where(eq(campaignsTable.id, params.data.id))
    .returning();

  if (!campaign) {
    res.status(404).json({ error: "Campaign not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
