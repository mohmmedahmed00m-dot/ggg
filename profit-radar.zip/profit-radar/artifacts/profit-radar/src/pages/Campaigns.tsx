import { Link } from "wouter";
import { useListCampaigns, useDeleteCampaign, getListCampaignsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Target, Trash2, Eye, TrendingUp, TrendingDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

function StatusBadge({ status }: { status: string }) {
  const configs = {
    planned: "bg-muted text-muted-foreground",
    active: "bg-primary/10 text-primary",
    completed: "bg-emerald-500/10 text-emerald-400",
  };
  return (
    <span className={cn("text-xs px-2 py-0.5 rounded font-medium", configs[status as keyof typeof configs] ?? configs.planned)}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

export default function Campaigns() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: campaigns, isLoading } = useListCampaigns();
  const deleteCampaign = useDeleteCampaign();

  function handleDelete(id: number) {
    if (!confirm("Delete this campaign?")) return;
    deleteCampaign.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCampaignsQueryKey() });
        toast({ title: "Campaign deleted" });
      },
    });
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Campaign Tracker</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Track your promotions and measure actual vs estimated revenue</p>
        </div>
        <Link href="/campaigns/new">
          <Button size="sm" className="gap-1.5" data-testid="button-create-campaign">
            <Plus className="w-3.5 h-3.5" />
            New Campaign
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="grid gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
      ) : !campaigns || campaigns.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center gap-3">
          <Target className="w-12 h-12 text-muted-foreground/30" />
          <div>
            <p className="font-medium text-foreground">No campaigns yet</p>
            <p className="text-sm text-muted-foreground mt-1">Track your promotions to measure real vs expected performance</p>
          </div>
          <Link href="/campaigns/new">
            <Button size="sm" className="mt-2">Create First Campaign</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {campaigns.map(campaign => {
            const hasRevenue = campaign.actualRevenue != null && campaign.estimatedRevenue != null;
            const ratio = hasRevenue
              ? (campaign.actualRevenue! / campaign.estimatedRevenue!) * 100
              : null;

            return (
              <div
                key={campaign.id}
                data-testid={`card-campaign-${campaign.id}`}
                className="bg-card border border-card-border rounded-xl p-5"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-foreground truncate">{campaign.offerTitle ?? `Campaign #${campaign.id}`}</h3>
                      <StatusBadge status={campaign.status} />
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                      <span className="capitalize">{campaign.trafficSource} traffic</span>
                      {campaign.listSize && <span>{campaign.listSize.toLocaleString()} subscribers</span>}
                      {campaign.startDate && <span>Started {campaign.startDate}</span>}
                    </div>

                    {/* Revenue Progress */}
                    <div className="mt-3 flex items-center gap-6">
                      <div>
                        <div className="text-xs text-muted-foreground mb-0.5">Estimated</div>
                        <div className="font-mono text-sm text-foreground">
                          {campaign.estimatedRevenue != null ? `$${campaign.estimatedRevenue.toFixed(2)}` : "—"}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-0.5">Actual</div>
                        <div className={cn("font-mono text-sm font-semibold", campaign.actualRevenue != null ? "text-emerald-400" : "text-muted-foreground")}>
                          {campaign.actualRevenue != null ? `$${campaign.actualRevenue.toFixed(2)}` : "—"}
                        </div>
                      </div>
                      {ratio != null && (
                        <div className="flex items-center gap-1">
                          {ratio >= 100 ? (
                            <TrendingUp className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-red-400" />
                          )}
                          <span className={cn("text-sm font-semibold", ratio >= 100 ? "text-emerald-400" : "text-red-400")}>
                            {ratio.toFixed(0)}%
                          </span>
                          <span className="text-xs text-muted-foreground">of target</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Link href={`/campaigns/${campaign.id}`}>
                      <Button variant="ghost" size="icon" className="h-8 w-8" data-testid={`button-view-campaign-${campaign.id}`}>
                        <Eye className="w-3.5 h-3.5" />
                      </Button>
                    </Link>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => handleDelete(campaign.id)}
                      data-testid={`button-delete-campaign-${campaign.id}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
