import { useGetProfile, useUpdateProfile, getGetProfileQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Save, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";

const schema = z.object({
  niche: z.string().min(1, "Niche is required"),
  listSize: z.coerce.number().min(0),
  primaryTrafficSource: z.string().optional(),
  targetAudience: z.string().optional(),
  experienceLevel: z.string().optional(),
  monthlyBudget: z.coerce.number().optional(),
});

type FormValues = z.infer<typeof schema>;

export default function Profile() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: profile, isLoading } = useGetProfile();
  const updateProfile = useUpdateProfile();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      niche: "",
      listSize: 0,
      primaryTrafficSource: "",
      targetAudience: "",
      experienceLevel: "intermediate",
    },
  });

  useEffect(() => {
    if (profile) {
      form.reset({
        niche: profile.niche,
        listSize: profile.listSize,
        primaryTrafficSource: profile.primaryTrafficSource ?? "",
        targetAudience: profile.targetAudience ?? "",
        experienceLevel: profile.experienceLevel ?? "intermediate",
        monthlyBudget: profile.monthlyBudget ?? undefined,
      });
    }
  }, [profile]);

  function onSubmit(values: FormValues) {
    updateProfile.mutate(
      { data: values },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetProfileQueryKey() });
          toast({ title: "Profile updated" });
        },
        onError: () => {
          toast({ title: "Failed to update profile", variant: "destructive" });
        },
      }
    );
  }

  if (isLoading) {
    return (
      <div className="p-6 max-w-xl mx-auto space-y-4">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-80 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-xl mx-auto space-y-6">
      <div>
        <h1 className="text-xl font-bold text-foreground">Profile & Settings</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Configure your niche and preferences to improve offer recommendations</p>
      </div>

      <div className="bg-card border border-card-border rounded-xl p-6">
        <div className="flex items-center gap-2 mb-5">
          <Settings className="w-4 h-4 text-muted-foreground" />
          <h2 className="text-sm font-semibold text-foreground">Affiliate Profile</h2>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <FormField
              control={form.control}
              name="niche"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Niche *</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Make Money Online, Email Marketing, AI Tools" {...field} data-testid="input-niche" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="listSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email List Size</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="5000" {...field} data-testid="input-list-size" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="monthlyBudget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Monthly Budget ($)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="500" {...field} data-testid="input-monthly-budget" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="primaryTrafficSource"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Primary Traffic Source</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger data-testid="select-traffic-source">
                        <SelectValue placeholder="Select..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="email">Email List</SelectItem>
                      <SelectItem value="social">Social Media</SelectItem>
                      <SelectItem value="paid">Paid Advertising</SelectItem>
                      <SelectItem value="organic">Organic / SEO</SelectItem>
                      <SelectItem value="mixed">Mixed</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="experienceLevel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Experience Level</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger data-testid="select-experience-level">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner (0-1 year)</SelectItem>
                      <SelectItem value="intermediate">Intermediate (1-3 years)</SelectItem>
                      <SelectItem value="advanced">Advanced (3+ years)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="targetAudience"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Target Audience Description</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Online entrepreneurs, digital marketers aged 25-45" {...field} data-testid="input-target-audience" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full gap-2" disabled={updateProfile.isPending} data-testid="button-save-profile">
              <Save className="w-4 h-4" />
              {updateProfile.isPending ? "Saving..." : "Save Profile"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
