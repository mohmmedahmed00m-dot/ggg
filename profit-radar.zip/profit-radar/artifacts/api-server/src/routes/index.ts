import { Router, type IRouter } from "express";
import healthRouter from "./health";
import offersRouter from "./offers";
import campaignsRouter from "./campaigns";
import profileRouter from "./profile";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(offersRouter);
router.use(campaignsRouter);
router.use(profileRouter);
router.use(dashboardRouter);

export default router;
