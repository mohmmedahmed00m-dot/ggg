import { Router, type IRouter } from "express";
import { eq, desc, avg, count, sum } from "drizzle-orm";
import { db, offersTable, campaignsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/dashboard/stats", async (_req, res): Promise<void> => {
  const offers = await db.select().from(offersTable);
  const campaigns = await db.select().from(campaignsTable);

  const totalOffers = offers.length;
  const promoteCount = offers.filter(o => o.recommendation === "promote").length;
  const watchCount = offers.filter(o => o.recommendation === "watch").length;
  const avoidCount = offers.filter(o => o.recommendation === "avoid").length;
  const activeCampaigns = campaigns.filter(c => c.status === "active").length;

  const totalEstimatedRevenue = campaigns.reduce((sum, c) => {
    return sum + (c.estimatedRevenue ? parseFloat(String(c.estimatedRevenue)) : 0);
  }, 0);

  const avgProfitScore =
    totalOffers > 0
      ? Math.round(offers.reduce((s, o) => s + o.profitScore, 0) / totalOffers)
      : 0;

  const topOffer = offers.sort((a, b) => b.profitScore - a.profitScore)[0];

  res.json({
    totalOffers,
    promoteCount,
    watchCount,
    avoidCount,
    activeCampaigns,
    totalEstimatedRevenue: Math.round(totalEstimatedRevenue * 100) / 100,
    avgProfitScore,
    topOfferTitle: topOffer?.title ?? null,
    topOfferScore: topOffer?.profitScore ?? null,
  });
});

router.get("/dashboard/profit-forecast", async (_req, res): Promise<void> => {
  const offers = await db
    .select()
    .from(offersTable)
    .where(eq(offersTable.recommendation, "promote"))
    .orderBy(desc(offersTable.profitScore))
    .limit(5);

  const forecast = offers.map(o => ({
    offerTitle: o.title,
    recommendation: o.recommendation,
    estimatedRevenue: o.estimatedWeeklyRevenue ? parseFloat(String(o.estimatedWeeklyRevenue)) : 0,
    profitScore: o.profitScore,
    platform: o.platform,
  }));

  res.json(forecast);
});

export default router;
