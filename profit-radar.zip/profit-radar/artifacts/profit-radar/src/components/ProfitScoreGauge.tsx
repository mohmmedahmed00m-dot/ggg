interface Props {
  score: number;
  size?: "sm" | "md" | "lg";
}

export default function ProfitScoreGauge({ score, size = "md" }: Props) {
  const clampedScore = Math.min(100, Math.max(0, score));
  const color =
    clampedScore >= 70 ? "#22c55e" : clampedScore >= 45 ? "#f59e0b" : "#ef4444";

  const sizes = {
    sm: { w: 56, r: 20, stroke: 4, fontSize: 11 },
    md: { w: 80, r: 30, stroke: 6, fontSize: 16 },
    lg: { w: 120, r: 45, stroke: 8, fontSize: 22 },
  };

  const { w, r, stroke, fontSize } = sizes[size];
  const cx = w / 2;
  const cy = w / 2;
  const circumference = 2 * Math.PI * r;
  const dashOffset = circumference * (1 - clampedScore / 100);

  return (
    <div data-testid={`gauge-profit-score-${clampedScore}`} className="inline-flex items-center justify-center">
      <svg width={w} height={w} className="transform -rotate-90">
        <circle
          cx={cx}
          cy={cy}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth={stroke}
        />
        <circle
          cx={cx}
          cy={cy}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 0.6s ease" }}
        />
        <text
          x={cx}
          y={cy}
          textAnchor="middle"
          dominantBaseline="middle"
          fontSize={fontSize}
          fontWeight={700}
          fill={color}
          transform={`rotate(90, ${cx}, ${cy})`}
          fontFamily="Inter, sans-serif"
        >
          {clampedScore}
        </text>
      </svg>
    </div>
  );
}
