import { useState } from "react";
import { Link } from "wouter";
import {
  useListOffers,
  useDeleteOffer,
  useAnalyzeOffer,
  getListOffersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Search, RefreshCw, Trash2, Eye, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import RecommendationBadge from "@/components/RecommendationBadge";
import ProfitScoreGauge from "@/components/ProfitScoreGauge";
import RiskPill from "@/components/RiskPill";
import { useToast } from "@/hooks/use-toast";

export default function Offers() {
  const [search, setSearch] = useState("");
  const [recFilter, setRecFilter] = useState("all");
  const [platformFilter, setPlatformFilter] = useState("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: offers, isLoading } = useListOffers();
  const deleteOffer = useDeleteOffer();
  const analyzeOffer = useAnalyzeOffer();

  const filtered = (offers ?? []).filter(o => {
    const matchSearch =
      !search ||
      o.title.toLowerCase().includes(search.toLowerCase()) ||
      (o.niche ?? "").toLowerCase().includes(search.toLowerCase());
    const matchRec = recFilter === "all" || o.recommendation === recFilter;
    const matchPlatform = platformFilter === "all" || o.platform === platformFilter;
    return matchSearch && matchRec && matchPlatform;
  });

  function handleDelete(id: number, title: string) {
    if (!confirm(`Delete "${title}"?`)) return;
    deleteOffer.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListOffersQueryKey() });
        toast({ title: "Offer deleted" });
      },
    });
  }

  function handleAnalyze(id: number) {
    analyzeOffer.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListOffersQueryKey() });
        toast({ title: "Analysis refreshed" });
      },
    });
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Offer Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Score and rank every offer before you promote</p>
        </div>
        <Link href="/offers/new">
          <Button size="sm" className="gap-1.5" data-testid="button-add-offer">
            <Plus className="w-3.5 h-3.5" />
            Scan Offer
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            data-testid="input-search-offers"
            placeholder="Search offers or niches..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 h-9 text-sm"
          />
        </div>
        <Select value={recFilter} onValueChange={setRecFilter}>
          <SelectTrigger className="w-36 h-9 text-sm" data-testid="select-recommendation-filter">
            <SelectValue placeholder="Recommendation" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="promote">Promote</SelectItem>
            <SelectItem value="watch">Watch</SelectItem>
            <SelectItem value="avoid">Avoid</SelectItem>
          </SelectContent>
        </Select>
        <Select value={platformFilter} onValueChange={setPlatformFilter}>
          <SelectTrigger className="w-36 h-9 text-sm" data-testid="select-platform-filter">
            <SelectValue placeholder="Platform" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Platforms</SelectItem>
            <SelectItem value="jvzoo">JVZoo</SelectItem>
            <SelectItem value="warriorplus">WarriorPlus</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-lg" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center gap-3">
          <Zap className="w-12 h-12 text-muted-foreground/30" />
          <div>
            <p className="font-medium text-foreground">No offers found</p>
            <p className="text-sm text-muted-foreground mt-1">
              {offers?.length === 0 ? "Scan your first offer to see its profit score" : "Try adjusting your filters"}
            </p>
          </div>
          {offers?.length === 0 && (
            <Link href="/offers/new">
              <Button size="sm" className="mt-2">Scan First Offer</Button>
            </Link>
          )}
        </div>
      ) : (
        <div className="bg-card border border-card-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide">Score</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide">Offer</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide hidden md:table-cell">Signal</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide hidden lg:table-cell">Risk</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide hidden lg:table-cell">Est. Revenue</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(offer => (
                <tr
                  key={offer.id}
                  data-testid={`row-offer-${offer.id}`}
                  className="hover:bg-accent/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <ProfitScoreGauge score={offer.profitScore} size="sm" />
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-foreground truncate max-w-[200px]">{offer.title}</div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${offer.platform === "jvzoo" ? "bg-blue-500/10 text-blue-400" : "bg-orange-500/10 text-orange-400"}`}>
                        {offer.platform === "jvzoo" ? "JVZoo" : "WarriorPlus"}
                      </span>
                      {offer.niche && <span className="text-xs text-muted-foreground">{offer.niche}</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <RecommendationBadge recommendation={offer.recommendation} size="sm" />
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <div className="space-y-0.5">
                      <RiskPill level={offer.refundRisk ?? "medium"} label="Refund" />
                      <RiskPill level={offer.saturationLevel ?? "medium"} label="Saturation" />
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    {offer.estimatedWeeklyRevenue != null ? (
                      <span className="text-emerald-400 font-mono text-sm">
                        ${offer.estimatedWeeklyRevenue.toFixed(2)}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => handleAnalyze(offer.id)}
                        data-testid={`button-analyze-offer-${offer.id}`}
                        disabled={analyzeOffer.isPending}
                        title="Re-analyze"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </Button>
                      <Link href={`/offers/${offer.id}`}>
                        <Button variant="ghost" size="icon" className="h-7 w-7" data-testid={`button-view-offer-${offer.id}`} title="View details">
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive"
                        onClick={() => handleDelete(offer.id, offer.title)}
                        data-testid={`button-delete-offer-${offer.id}`}
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
