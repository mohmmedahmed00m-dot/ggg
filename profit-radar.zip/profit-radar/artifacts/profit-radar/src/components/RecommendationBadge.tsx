import { cn } from "@/lib/utils";
import { TrendingUp, Eye, TrendingDown } from "lucide-react";

interface Props {
  recommendation: string;
  size?: "sm" | "md";
}

export default function RecommendationBadge({ recommendation, size = "md" }: Props) {
  const configs = {
    promote: {
      label: "PROMOTE",
      icon: TrendingUp,
      className: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
    },
    watch: {
      label: "WATCH",
      icon: Eye,
      className: "bg-amber-500/10 text-amber-400 border border-amber-500/20",
    },
    avoid: {
      label: "AVOID",
      icon: TrendingDown,
      className: "bg-red-500/10 text-red-400 border border-red-500/20",
    },
  };

  const config = configs[recommendation as keyof typeof configs] ?? configs.watch;
  const Icon = config.icon;

  return (
    <span
      data-testid={`badge-recommendation-${recommendation}`}
      className={cn(
        "inline-flex items-center gap-1 font-semibold rounded-md tracking-wide uppercase",
        size === "sm" ? "px-1.5 py-0.5 text-[10px]" : "px-2 py-1 text-xs",
        config.className
      )}
    >
      <Icon className={cn("flex-shrink-0", size === "sm" ? "w-2.5 h-2.5" : "w-3 h-3")} />
      {config.label}
    </span>
  );
}
