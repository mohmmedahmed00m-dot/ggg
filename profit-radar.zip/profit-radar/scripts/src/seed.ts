import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { offersTable, campaignsTable } from "../../lib/db/src/schema/index.js";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

const seedOffers = [
  {
    title: "AI Traffic Dominator Pro",
    platform: "jvzoo",
    url: "https://jvzoo.com/offers/ai-traffic-dominator",
    vendorName: "Mike Johnson",
    niche: "make money online",
    epc: "1.87",
    commissionPercent: "50",
    refundRate: "6.5",
    gravity: "94.2",
    price: "27",
    profitScore: 82,
    recommendation: "promote",
    saturationLevel: "medium",
    refundRisk: "low",
    marketingAngle: "Lead with proof: showcase real results from existing buyers",
    estimatedWeeklyRevenue: "280.50",
    notes: "Top performer in MMO niche this quarter",
  },
  {
    title: "Email Mastery Blueprint 3.0",
    platform: "jvzoo",
    vendorName: "Sarah Chen",
    niche: "email marketing",
    epc: "2.34",
    commissionPercent: "75",
    refundRate: "4.2",
    gravity: "142.8",
    price: "47",
    profitScore: 91,
    recommendation: "promote",
    saturationLevel: "medium",
    refundRisk: "low",
    marketingAngle: "Focus on the time-saving angle — busy buyers convert better",
    estimatedWeeklyRevenue: "394.65",
    notes: "Excellent refund rate, high commission",
  },
  {
    title: "Social Media Profits Academy",
    platform: "warriorplus",
    vendorName: "Dave Richards",
    niche: "social media marketing",
    epc: "0.92",
    commissionPercent: "50",
    refundRate: "14.8",
    gravity: "38.5",
    price: "37",
    profitScore: 48,
    recommendation: "watch",
    saturationLevel: "low",
    refundRisk: "high",
    marketingAngle: "Emphasize the ROI and payback within 30 days",
    estimatedWeeklyRevenue: "138.00",
    notes: "Refund rate is concerning, monitor closely",
  },
  {
    title: "Crypto Trading Secrets Exposed",
    platform: "warriorplus",
    niche: "crypto",
    epc: "0.41",
    commissionPercent: "50",
    refundRate: "24.5",
    gravity: "12.1",
    price: "17",
    profitScore: 22,
    recommendation: "avoid",
    saturationLevel: "low",
    refundRisk: "high",
    marketingAngle: "Position as the missing piece in their current workflow",
    estimatedWeeklyRevenue: "61.50",
  },
  {
    title: "List Building Masterclass 2.0",
    platform: "jvzoo",
    vendorName: "Tom Williams",
    niche: "email marketing",
    epc: "1.45",
    commissionPercent: "60",
    refundRate: "8.3",
    gravity: "67.4",
    price: "27",
    profitScore: 74,
    recommendation: "promote",
    saturationLevel: "medium",
    refundRisk: "medium",
    marketingAngle: "Use scarcity — highlight launch pricing before it expires",
    estimatedWeeklyRevenue: "217.50",
  },
  {
    title: "Freelance Freedom Formula",
    platform: "warriorplus",
    vendorName: "Jessica Park",
    niche: "freelancing",
    epc: "1.12",
    commissionPercent: "50",
    refundRate: "11.2",
    gravity: "29.8",
    price: "37",
    profitScore: 55,
    recommendation: "watch",
    saturationLevel: "low",
    refundRisk: "medium",
    marketingAngle: "Target the frustrated with current tools segment",
    estimatedWeeklyRevenue: "168.00",
  },
];

async function main() {
  console.log("Seeding offers...");
  const insertedOffers = await db.insert(offersTable).values(seedOffers).returning();
  console.log(`Seeded ${insertedOffers.length} offers`);

  const firstOffer = insertedOffers[0];
  const secondOffer = insertedOffers[1];

  await db.insert(campaignsTable).values([
    {
      offerId: firstOffer.id,
      trafficSource: "email",
      listSize: 5000,
      estimatedRevenue: "280.50",
      actualRevenue: "312.40",
      startDate: "2026-06-01",
      endDate: "2026-06-07",
      status: "completed",
      notes: "Mailed to warm segment, crushed the estimate",
    },
    {
      offerId: secondOffer.id,
      trafficSource: "email",
      listSize: 8000,
      estimatedRevenue: "394.65",
      startDate: "2026-06-25",
      status: "active",
      notes: "Currently mailing to full list",
    },
  ]);
  console.log("Seeded 2 campaigns");
  await pool.end();
}

main().catch(console.error);
