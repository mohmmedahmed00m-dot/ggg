import { pgTable, serial, text, integer, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { offersTable } from "./offers";

export const campaignsTable = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  offerId: integer("offer_id").notNull().references(() => offersTable.id, { onDelete: "cascade" }),
  trafficSource: text("traffic_source").notNull().default("email"),
  listSize: integer("list_size"),
  estimatedRevenue: numeric("estimated_revenue", { precision: 10, scale: 2 }),
  actualRevenue: numeric("actual_revenue", { precision: 10, scale: 2 }),
  startDate: text("start_date"),
  endDate: text("end_date"),
  status: text("status").notNull().default("planned"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertCampaignSchema = createInsertSchema(campaignsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaignsTable.$inferSelect;
