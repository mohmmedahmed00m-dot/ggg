import { useRoute, Link } from "wouter";
import {
  useGetCampaign,
  useUpdateCampaign,
  getGetCampaignQueryKey,
  getListCampaignsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function CampaignDetail() {
  const [, params] = useRoute("/campaigns/:id");
  const id = parseInt(params?.id ?? "0", 10);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: campaign, isLoading } = useGetCampaign(id, {
    query: { enabled: !!id, queryKey: getGetCampaignQueryKey(id) },
  });

  const updateCampaign = useUpdateCampaign();
  const [actualRevenue, setActualRevenue] = useState("");
  const [status, setStatus] = useState("");

  function handleSave() {
    const updates: { actualRevenue?: number; status?: string } = {};
    if (actualRevenue) updates.actualRevenue = parseFloat(actualRevenue);
    if (status) updates.status = status;

    updateCampaign.mutate(
      { id, data: updates },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCampaignQueryKey(id) });
          queryClient.invalidateQueries({ queryKey: getListCampaignsQueryKey() });
          toast({ title: "Campaign updated" });
          setActualRevenue("");
          setStatus("");
        },
      }
    );
  }

  if (isLoading) {
    return (
      <div className="p-6 max-w-2xl mx-auto space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 rounded-xl" />
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="p-6 text-center text-muted-foreground">
        Campaign not found
        <Link href="/campaigns"><Button variant="link" className="mt-2 block mx-auto">Back</Button></Link>
      </div>
    );
  }

  const ratio =
    campaign.actualRevenue != null && campaign.estimatedRevenue != null && campaign.estimatedRevenue !== 0
      ? (campaign.actualRevenue / campaign.estimatedRevenue) * 100
      : null;

  const statusColors: Record<string, string> = {
    planned: "text-muted-foreground",
    active: "text-primary",
    completed: "text-emerald-400",
  };

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/campaigns">
          <Button variant="ghost" size="icon" className="h-8 w-8" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-xl font-bold text-foreground">{campaign.offerTitle ?? `Campaign #${campaign.id}`}</h1>
          <span className={cn("text-sm font-medium", statusColors[campaign.status] ?? "text-muted-foreground")}>
            {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
          </span>
        </div>
      </div>

      {/* Revenue Overview */}
      <div className="bg-card border border-card-border rounded-xl p-6">
        <h2 className="text-sm font-semibold text-foreground mb-4">Revenue Performance</h2>
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div data-testid="metric-estimated-revenue">
            <div className="text-xs text-muted-foreground mb-1">Estimated</div>
            <div className="text-2xl font-bold text-foreground">
              {campaign.estimatedRevenue != null ? `$${campaign.estimatedRevenue.toFixed(2)}` : "—"}
            </div>
          </div>
          <div data-testid="metric-actual-revenue">
            <div className="text-xs text-muted-foreground mb-1">Actual</div>
            <div className={cn("text-2xl font-bold", campaign.actualRevenue != null ? "text-emerald-400" : "text-muted-foreground")}>
              {campaign.actualRevenue != null ? `$${campaign.actualRevenue.toFixed(2)}` : "—"}
            </div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground mb-1">Performance</div>
            <div className={cn("text-2xl font-bold", ratio != null ? (ratio >= 100 ? "text-emerald-400" : "text-red-400") : "text-muted-foreground")}>
              {ratio != null ? `${ratio.toFixed(0)}%` : "—"}
            </div>
          </div>
        </div>

        {ratio != null && (
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className={cn("h-full rounded-full transition-all", ratio >= 100 ? "bg-emerald-500" : "bg-amber-500")}
              style={{ width: `${Math.min(100, ratio)}%` }}
            />
          </div>
        )}
      </div>

      {/* Details */}
      <div className="bg-card border border-card-border rounded-xl p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">Campaign Details</h2>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-xs text-muted-foreground mb-0.5">Traffic Source</div>
            <div className="font-medium capitalize">{campaign.trafficSource}</div>
          </div>
          {campaign.listSize && (
            <div>
              <div className="text-xs text-muted-foreground mb-0.5">List Size</div>
              <div className="font-medium">{campaign.listSize.toLocaleString()}</div>
            </div>
          )}
          {campaign.startDate && (
            <div>
              <div className="text-xs text-muted-foreground mb-0.5">Start Date</div>
              <div className="font-medium">{campaign.startDate}</div>
            </div>
          )}
          {campaign.endDate && (
            <div>
              <div className="text-xs text-muted-foreground mb-0.5">End Date</div>
              <div className="font-medium">{campaign.endDate}</div>
            </div>
          )}
        </div>
        {campaign.notes && (
          <div className="mt-4 pt-4 border-t border-border">
            <div className="text-xs text-muted-foreground mb-1">Notes</div>
            <div className="text-sm">{campaign.notes}</div>
          </div>
        )}
      </div>

      {/* Update Panel */}
      <div className="bg-card border border-card-border rounded-xl p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">Update Campaign</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-xs mb-1.5 block">Actual Revenue ($)</Label>
            <Input
              type="number"
              step="0.01"
              placeholder={campaign.actualRevenue?.toString() ?? "Enter actual revenue"}
              value={actualRevenue}
              onChange={e => setActualRevenue(e.target.value)}
              data-testid="input-actual-revenue"
            />
          </div>
          <div>
            <Label className="text-xs mb-1.5 block">Status</Label>
            <Select value={status || campaign.status} onValueChange={setStatus}>
              <SelectTrigger data-testid="select-campaign-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="planned">Planned</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button
          className="mt-4 gap-2"
          onClick={handleSave}
          disabled={updateCampaign.isPending || (!actualRevenue && !status)}
          data-testid="button-save-campaign"
        >
          <Save className="w-4 h-4" />
          {updateCampaign.isPending ? "Saving..." : "Save Updates"}
        </Button>
      </div>
    </div>
  );
}
