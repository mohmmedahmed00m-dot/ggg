import { cn } from "@/lib/utils";

interface Props {
  level: string;
  label?: string;
}

export default function RiskPill({ level, label }: Props) {
  const colors = {
    low: "text-emerald-400",
    medium: "text-amber-400",
    high: "text-red-400",
  };
  const dots = {
    low: "bg-emerald-400",
    medium: "bg-amber-400",
    high: "bg-red-400",
  };

  const color = colors[level as keyof typeof colors] ?? colors.medium;
  const dot = dots[level as keyof typeof dots] ?? dots.medium;

  return (
    <span className={cn("inline-flex items-center gap-1.5 text-xs font-medium", color)}>
      <span className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", dot)} />
      {label ? `${label}: ` : ""}{level.charAt(0).toUpperCase() + level.slice(1)}
    </span>
  );
}
