import { Router, type IRouter } from "express";
import { db, profilesTable } from "@workspace/db";
import { UpdateProfileBody } from "@workspace/api-zod";

const router: IRouter = Router();

function formatProfile(profile: typeof profilesTable.$inferSelect) {
  return {
    ...profile,
    monthlyBudget: profile.monthlyBudget != null ? parseFloat(String(profile.monthlyBudget)) : null,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt.toISOString(),
  };
}

async function getOrCreateProfile() {
  const [existing] = await db.select().from(profilesTable).limit(1);
  if (existing) return existing;

  const [created] = await db
    .insert(profilesTable)
    .values({
      niche: "make money online",
      listSize: 0,
      primaryTrafficSource: "email",
      experienceLevel: "intermediate",
    })
    .returning();

  return created;
}

router.get("/profile", async (_req, res): Promise<void> => {
  const profile = await getOrCreateProfile();
  res.json(formatProfile(profile));
});

router.patch("/profile", async (req, res): Promise<void> => {
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const profile = await getOrCreateProfile();

  const updateData: Partial<typeof profilesTable.$inferInsert> = {};
  if (parsed.data.niche != null) updateData.niche = parsed.data.niche;
  if (parsed.data.listSize != null) updateData.listSize = parsed.data.listSize;
  if (parsed.data.primaryTrafficSource != null) updateData.primaryTrafficSource = parsed.data.primaryTrafficSource;
  if (parsed.data.targetAudience != null) updateData.targetAudience = parsed.data.targetAudience;
  if (parsed.data.experienceLevel != null) updateData.experienceLevel = parsed.data.experienceLevel;
  if (parsed.data.monthlyBudget != null) updateData.monthlyBudget = parsed.data.monthlyBudget.toString();

  const { eq } = await import("drizzle-orm");
  const [updated] = await db
    .update(profilesTable)
    .set(updateData)
    .where(eq(profilesTable.id, profile.id))
    .returning();

  res.json(formatProfile(updated!));
});

export default router;
