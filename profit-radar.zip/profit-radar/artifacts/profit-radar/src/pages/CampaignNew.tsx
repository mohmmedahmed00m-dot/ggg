import { useLocation, useSearch } from "wouter";
import { useCreateCampaign, useListOffers, getListCampaignsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Target } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  offerId: z.coerce.number().min(1, "Select an offer"),
  trafficSource: z.string().min(1, "Traffic source is required"),
  listSize: z.coerce.number().optional(),
  estimatedRevenue: z.coerce.number().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

export default function CampaignNew() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const prefilledOfferId = params.get("offerId");

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createCampaign = useCreateCampaign();
  const { data: offers } = useListOffers();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      offerId: prefilledOfferId ? parseInt(prefilledOfferId) : undefined,
      trafficSource: "email",
      notes: "",
    },
  });

  function onSubmit(values: FormValues) {
    createCampaign.mutate(
      { data: values },
      {
        onSuccess: campaign => {
          queryClient.invalidateQueries({ queryKey: getListCampaignsQueryKey() });
          toast({ title: "Campaign created" });
          setLocation(`/campaigns/${campaign.id}`);
        },
        onError: () => {
          toast({ title: "Failed to create campaign", variant: "destructive" });
        },
      }
    );
  }

  return (
    <div className="p-6 max-w-xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/campaigns">
          <Button variant="ghost" size="icon" className="h-8 w-8" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-xl font-bold text-foreground">New Campaign</h1>
          <p className="text-sm text-muted-foreground">Plan your promotion strategy</p>
        </div>
      </div>

      <div className="bg-card border border-card-border rounded-xl p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <FormField
              control={form.control}
              name="offerId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Offer *</FormLabel>
                  <Select value={field.value?.toString()} onValueChange={v => field.onChange(parseInt(v))}>
                    <FormControl>
                      <SelectTrigger data-testid="select-offer">
                        <SelectValue placeholder="Select an offer" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {(offers ?? []).map(o => (
                        <SelectItem key={o.id} value={o.id.toString()}>
                          {o.title} (Score: {o.profitScore})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="trafficSource"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Traffic Source *</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger data-testid="select-traffic-source">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="email">Email List</SelectItem>
                      <SelectItem value="social">Social Media</SelectItem>
                      <SelectItem value="paid">Paid Ads</SelectItem>
                      <SelectItem value="organic">Organic / SEO</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="listSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>List Size</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="5000" {...field} data-testid="input-list-size" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="estimatedRevenue"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Est. Revenue ($)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="500" {...field} data-testid="input-estimated-revenue" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-start-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-end-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Campaign strategy or angles..." rows={2} {...field} data-testid="input-campaign-notes" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full gap-2" disabled={createCampaign.isPending} data-testid="button-submit-campaign">
              <Target className="w-4 h-4" />
              {createCampaign.isPending ? "Creating..." : "Create Campaign"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
