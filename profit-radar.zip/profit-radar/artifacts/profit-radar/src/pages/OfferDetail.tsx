import { useRoute, Link, useLocation } from "wouter";
import {
  useGetOffer,
  useUpdateOffer,
  useAnalyzeOffer,
  getGetOfferQueryKey,
  getListOffersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, RefreshCw, ExternalLink, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import RecommendationBadge from "@/components/RecommendationBadge";
import ProfitScoreGauge from "@/components/ProfitScoreGauge";
import RiskPill from "@/components/RiskPill";
import { useToast } from "@/hooks/use-toast";

export default function OfferDetail() {
  const [, params] = useRoute("/offers/:id");
  const id = parseInt(params?.id ?? "0", 10);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: offer, isLoading } = useGetOffer(id, {
    query: { enabled: !!id, queryKey: getGetOfferQueryKey(id) },
  });

  const analyzeOffer = useAnalyzeOffer();

  function handleAnalyze() {
    analyzeOffer.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetOfferQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListOffersQueryKey() });
        toast({ title: "Analysis refreshed" });
      },
    });
  }

  if (isLoading) {
    return (
      <div className="p-6 max-w-3xl mx-auto space-y-5">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-48 rounded-xl" />
        <Skeleton className="h-32 rounded-xl" />
      </div>
    );
  }

  if (!offer) {
    return (
      <div className="p-6 text-center text-muted-foreground">
        <p>Offer not found</p>
        <Link href="/offers"><Button variant="link" className="mt-2">Back to offers</Button></Link>
      </div>
    );
  }

  const metrics = [
    { label: "EPC", value: offer.epc != null ? `$${offer.epc.toFixed(4)}` : "—" },
    { label: "Commission", value: offer.commissionPercent != null ? `${offer.commissionPercent}%` : "—" },
    { label: "Refund Rate", value: offer.refundRate != null ? `${offer.refundRate}%` : "—" },
    { label: "Gravity", value: offer.gravity != null ? offer.gravity.toFixed(1) : "—" },
    { label: "Price", value: offer.price != null ? `$${offer.price.toFixed(2)}` : "—" },
    { label: "Est. Weekly Revenue", value: offer.estimatedWeeklyRevenue != null ? `$${offer.estimatedWeeklyRevenue.toFixed(2)}` : "—" },
  ];

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start gap-3">
        <Link href="/offers">
          <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0 mt-0.5" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-bold text-foreground leading-tight">{offer.title}</h1>
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <span className={`text-xs px-2 py-0.5 rounded font-medium ${offer.platform === "jvzoo" ? "bg-blue-500/10 text-blue-400 border border-blue-500/20" : "bg-orange-500/10 text-orange-400 border border-orange-500/20"}`}>
              {offer.platform === "jvzoo" ? "JVZoo" : "WarriorPlus"}
            </span>
            {offer.niche && <span className="text-xs text-muted-foreground">{offer.niche}</span>}
            {offer.vendorName && <span className="text-xs text-muted-foreground">by {offer.vendorName}</span>}
          </div>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <Button variant="outline" size="sm" onClick={handleAnalyze} disabled={analyzeOffer.isPending} className="gap-1.5 text-xs" data-testid="button-re-analyze">
            <RefreshCw className="w-3.5 h-3.5" />
            Re-analyze
          </Button>
          {offer.url && (
            <a href={offer.url} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs" data-testid="button-open-url">
                <ExternalLink className="w-3.5 h-3.5" />
                View Offer
              </Button>
            </a>
          )}
        </div>
      </div>

      {/* Score + Recommendation */}
      <div className="bg-card border border-card-border rounded-xl p-6 flex flex-col sm:flex-row items-center gap-6">
        <ProfitScoreGauge score={offer.profitScore} size="lg" />
        <div className="flex-1 text-center sm:text-left">
          <div className="text-xs text-muted-foreground uppercase tracking-wider font-medium mb-2">Profit Intelligence Score</div>
          <div className="text-4xl font-bold text-foreground mb-2">{offer.profitScore}<span className="text-lg text-muted-foreground">/100</span></div>
          <RecommendationBadge recommendation={offer.recommendation} />
          <p className="text-sm text-muted-foreground mt-3 max-w-sm">
            {offer.recommendation === "promote"
              ? "This offer has strong profit potential. High EPC, manageable refund risk, and good market fit."
              : offer.recommendation === "watch"
              ? "This offer shows moderate potential. Monitor performance data before committing full resources."
              : "Current metrics suggest this offer carries significant risk. Consider avoiding or waiting for better data."}
          </p>
        </div>
        <div className="flex flex-col gap-3">
          <div className="text-center">
            <div className="text-xs text-muted-foreground mb-1">Refund Risk</div>
            <RiskPill level={offer.refundRisk} />
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground mb-1">Saturation</div>
            <RiskPill level={offer.saturationLevel} />
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="bg-card border border-card-border rounded-xl p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">Performance Metrics</h2>
        <div className="grid grid-cols-3 gap-4">
          {metrics.map(m => (
            <div key={m.label} data-testid={`metric-${m.label.toLowerCase().replace(/\s+/g, "-")}`}>
              <div className="text-xs text-muted-foreground mb-1">{m.label}</div>
              <div className="text-lg font-bold text-foreground font-mono">{m.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Marketing Angle */}
      {offer.marketingAngle && (
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-5">
          <div className="text-xs text-primary font-semibold uppercase tracking-wider mb-2">Recommended Marketing Angle</div>
          <p className="text-sm text-foreground">{offer.marketingAngle}</p>
        </div>
      )}

      {/* Notes */}
      {offer.notes && (
        <div className="bg-card border border-card-border rounded-xl p-5">
          <div className="text-xs text-muted-foreground uppercase tracking-wider font-medium mb-2">Notes</div>
          <p className="text-sm text-foreground">{offer.notes}</p>
        </div>
      )}

      {/* Create Campaign */}
      <div className="flex justify-end">
        <Link href={`/campaigns/new?offerId=${offer.id}`}>
          <Button className="gap-2" data-testid="button-create-campaign">
            <Target className="w-4 h-4" />
            Create Campaign
          </Button>
        </Link>
      </div>
    </div>
  );
}
