import { pgTable, serial, text, numeric, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const offersTable = pgTable("offers", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  platform: text("platform").notNull().default("jvzoo"),
  url: text("url"),
  vendorName: text("vendor_name"),
  niche: text("niche"),
  epc: numeric("epc", { precision: 10, scale: 4 }),
  commissionPercent: numeric("commission_percent", { precision: 5, scale: 2 }),
  refundRate: numeric("refund_rate", { precision: 5, scale: 2 }),
  gravity: numeric("gravity", { precision: 10, scale: 4 }),
  price: numeric("price", { precision: 10, scale: 2 }),
  profitScore: real("profit_score").notNull().default(0),
  recommendation: text("recommendation").notNull().default("watch"),
  saturationLevel: text("saturation_level").notNull().default("medium"),
  refundRisk: text("refund_risk").notNull().default("medium"),
  marketingAngle: text("marketing_angle"),
  estimatedWeeklyRevenue: numeric("estimated_weekly_revenue", { precision: 10, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertOfferSchema = createInsertSchema(offersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type Offer = typeof offersTable.$inferSelect;
