# ProfitRadar

Affiliate Profit Intelligence System — scores and ranks JVZoo/WarriorPlus offers before you promote them.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/profit-radar run dev` — run the frontend (port 18912)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string (see `.env.example`)
- Required env: `SESSION_SECRET` — random secret string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 (port 8080, path `/api`)
- Frontend: React 19 + Vite (port 18912, path `/`)
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec → TanStack Query hooks + Zod schemas)
- Build: esbuild (CJS bundle for API), Vite (for frontend)
- UI: shadcn/ui, Tailwind CSS v4, Recharts, Wouter (routing)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for all API contracts)
- `lib/api-client-react/src/generated/` — generated TanStack Query hooks (do not edit manually)
- `lib/api-zod/src/generated/` — generated Zod schemas (do not edit manually)
- `lib/db/src/schema/` — Drizzle ORM table definitions (offers, campaigns, profiles)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/profit-radar/src/pages/` — React page components
- `artifacts/profit-radar/src/components/` — shared UI components

## Architecture decisions

- **Contract-first API**: OpenAPI spec defined first, hooks/schemas auto-generated via Orval. Never write API client code manually.
- **Dark mode by default**: CSS vars set to dark navy palette in `:root` — no `.dark` class toggle needed.
- **Profit Score algorithm**: Weighted scoring in `artifacts/api-server/src/routes/offers.ts` → `computeProfitScore()`. Inputs: EPC (35pts), commission (20pts), refund rate (25pts), gravity (20pts).
- **Single profile pattern**: Only one profile row exists per deployment (getOrCreate pattern in profile route).
- **Path-based routing**: Global reverse proxy routes `/api` → api-server (8080), `/` → profit-radar (18912).

## Product

- **Offer Intelligence**: Track offers with EPC, commission, refund rate, gravity → auto-computed profit score (0–100) with PROMOTE / WATCH / AVOID recommendation
- **Campaign Tracker**: Link campaigns to offers, track estimated vs actual revenue
- **Dashboard**: Stats overview, profit forecast chart, weekly top picks leaderboard
- **Profile**: Configure niche, list size, traffic source, experience level

## Setup (local development)

```bash
# 1. Copy env file and fill in values
cp .env.example .env

# 2. Install dependencies
pnpm install

# 3. Push DB schema
pnpm --filter @workspace/db run push

# 4. Start API server (terminal 1)
pnpm --filter @workspace/api-server run dev

# 5. Start frontend (terminal 2)
pnpm --filter @workspace/profit-radar run dev
```

## User preferences

- Always dark mode (deep navy/slate palette)
- Decision-first UX — score before promote
- Dense, information-rich layout (trading terminal style)
- No emojis in the UI

## Gotchas

- After editing OpenAPI spec, always run `pnpm --filter @workspace/api-spec run codegen` before using hooks.
- After editing `lib/db` schema, run `pnpm --filter @workspace/db run push` to sync with DB.
- Do NOT run `pnpm dev` at workspace root — use per-artifact commands or workflow restart.
- `pnpm run typecheck` is the canonical check — trust it over editor LSP state.
- Proxy routes paths as-is (no rewriting) — services must handle their full base path.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
